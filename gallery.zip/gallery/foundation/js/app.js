jQuery(document).ready(function($) {
$(document).foundation();
});